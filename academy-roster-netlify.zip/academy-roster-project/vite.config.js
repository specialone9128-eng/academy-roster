import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { VitePWA } from "vite-plugin-pwa";

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: "autoUpdate",
      includeAssets: ["icon-32.png", "icon-180.png"],
      manifest: {
        name: "أكاديمية أسباير - فرع المنيهلة",
        short_name: "أسباير",
        description: "تطبيق إدارة لاعبي أكاديمية أسباير - فرع المنيهلة",
        theme_color: "#0B1E3D",
        background_color: "#0B1E3D",
        display: "standalone",
        orientation: "portrait",
        start_url: "/",
        dir: "rtl",
        lang: "ar",
        icons: [
          { src: "icon-192.png", sizes: "192x192", type: "image/png" },
          { src: "icon-512.png", sizes: "512x512", type: "image/png" },
          { src: "icon-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
        ],
      },
      workbox: {
        globPatterns: ["**/*.{js,css,html,ico,png,jpg,svg}"],
      },
    }),
  ],
});
