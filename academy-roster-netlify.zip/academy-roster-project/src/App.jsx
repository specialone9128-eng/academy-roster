import React, { useState, useEffect, useMemo, useRef } from "react";
import * as XLSX from "xlsx";
import logoAsset from "./assets/logo.jpg";
import storage from "./storage";
import {
  Search, Plus, BarChart3, Settings2, X, Check, Lock, Download,
  FileSpreadsheet, FileText, Upload, Share2, Moon, SunMedium,
  ChevronLeft, Trash2, Pencil, ShieldCheck, Users, Filter as FilterIcon,
  Home as HomeIcon, KeyRound, Shirt, Wallet, PackageCheck,
} from "lucide-react";

/* ============ الشعار (مضمّن) ============ */
const LOGO_SRC = logoAsset;

const SIZES = ["TXS", "TS", "TM", "T6", "T8", "T10", "T12", "T14", "T26"];
const CATEGORIES = ["BC1", "BC2", "VC", "VE", "MV", "JA", "BO"];
const MONTHLY_FEES = ["60", "50", "40"];
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);

const STATUS_CONFIG = {
  green: { label: "دفع واستلم", dot: "#22C55E", soft: "#DCFCE7", text: "#15803D" },
  yellow: { label: "دفع ولم يستلم", dot: "#F59E0B", soft: "#FEF3C7", text: "#B45309" },
  red: { label: "لم يدفع (استلم)", dot: "#EF4444", soft: "#FEE2E2", text: "#B91C1C" },
  blue: { label: "لم يدفع ولم يستلم", dot: "#3B82F6", soft: "#DBEAFE", text: "#1D4ED8" },
};
function getStatusKey(p) {
  if (p.paid && p.received) return "green";
  if (p.paid && !p.received) return "yellow";
  if (!p.paid && p.received) return "red";
  return "blue";
}

const NAVY = "#0B1E3D";
const NAVY_DEEP = "#081530";
const LIME = "#7BC142";
const LIME_DARK = "#5FA22E";

export default function App() {
  const [loaded, setLoaded] = useState(false);
  const [players, setPlayers] = useState([]);
  const [settings, setSettings] = useState({ pin: null, dark: false });
  const [unlocked, setUnlocked] = useState(false);

  const [tab, setTab] = useState("home");
  const [query, setQuery] = useState("");
  const [teamFilter, setTeamFilter] = useState("الكل");
  const [sizeFilter, setSizeFilter] = useState("الكل");
  const [feeFilter, setFeeFilter] = useState("الكل");
  const [paidFilter, setPaidFilter] = useState("الكل");
  const [receivedFilter, setReceivedFilter] = useState("الكل");
  const [showFilters, setShowFilters] = useState(false);

  const [editingId, setEditingId] = useState(null);
  const [detailPlayer, setDetailPlayer] = useState(null);

  const fileInputRef = useRef(null);

  /* -------- تحميل البيانات من التخزين -------- */
  useEffect(() => {
    (async () => {
      try {
        const p = await storage.get("roster-players", false);
        if (p) setPlayers(JSON.parse(p.value));
      } catch (e) {}
      try {
        const s = await storage.get("roster-settings", false);
        if (s) setSettings(JSON.parse(s.value));
      } catch (e) {}
      setLoaded(true);
    })();
  }, []);

  useEffect(() => {
    if (!loaded) return;
    storage.set("roster-players", JSON.stringify(players), false).catch(() => {});
  }, [players, loaded]);

  useEffect(() => {
    if (!loaded) return;
    storage.set("roster-settings", JSON.stringify(settings), false).catch(() => {});
  }, [settings, loaded]);

  const dark = settings.dark;
  const t = dark
    ? {
        bg: "#0B1626",
        card: "#132238",
        cardBorder: "#22334D",
        text: "#F2F5F8",
        muted: "#8CA0B8",
        input: "#0F2038",
        inputBorder: "#25395A",
      }
    : {
        bg: "#EEF4EF",
        card: "#FFFFFF",
        cardBorder: "#D6E6DB",
        text: "#0B1E3D",
        muted: "#4C6558",
        input: "#FFFFFF",
        inputBorder: "#D6E6DB",
      };

  /* -------- بيانات محسوبة -------- */
  const filtered = useMemo(() => {
    return players.filter((p) => {
      if (query.trim() && !p.name.toLowerCase().includes(query.trim().toLowerCase())) return false;
      if (teamFilter !== "الكل" && p.team !== teamFilter) return false;
      if (sizeFilter !== "الكل" && p.size !== sizeFilter) return false;
      if (feeFilter !== "الكل" && p.fee !== feeFilter) return false;
      if (paidFilter === "مدفوع" && !p.paid) return false;
      if (paidFilter === "غير مدفوع" && p.paid) return false;
      if (receivedFilter === "مستلم" && !p.received) return false;
      if (receivedFilter === "غير مستلم" && p.received) return false;
      return true;
    });
  }, [players, query, teamFilter, sizeFilter, feeFilter, paidFilter, receivedFilter]);

  const stats = useMemo(() => {
    const total = players.length;
    const paidCount = players.filter((p) => p.paid).length;
    const notPaidCount = total - paidCount;
    const receivedCount = players.filter((p) => p.received).length;
    const notReceivedCount = total - receivedCount;
    const perTeam = {};
    const perSize = {};
    const perFee = {};
    players.forEach((p) => {
      const tm = p.team || "بدون فريق";
      perTeam[tm] = (perTeam[tm] || 0) + 1;
      perSize[p.size] = (perSize[p.size] || 0) + 1;
      if (p.fee) perFee[p.fee] = (perFee[p.fee] || 0) + 1;
    });
    return { total, paidCount, notPaidCount, receivedCount, notReceivedCount, perTeam, perSize, perFee };
  }, [players]);

  /* -------- عمليات اللاعبين -------- */
  function savePlayer(data) {
    if (editingId) {
      setPlayers((prev) => prev.map((p) => (p.id === editingId ? { ...p, ...data } : p)));
    } else {
      setPlayers((prev) => [...prev, { id: uid(), ...data }]);
    }
    setEditingId(null);
    setTab("home");
  }
  function deletePlayer(id) {
    setPlayers((prev) => prev.filter((p) => p.id !== id));
    setDetailPlayer(null);
  }

  /* -------- تصدير Excel -------- */
  function exportExcel() {
    const rows = players.map((p) => ({
      "الاسم واللقب": p.name,
      الفريق: p.team,
      المقاس: p.size,
      "معلوم الشهر": p.fee || "",
      مدفوع: p.paid ? "نعم" : "لا",
      مستلم: p.received ? "نعم" : "لا",
      ملاحظة: p.remark || "",
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "اللاعبون");
    XLSX.writeFile(wb, "لاعبو_الأكاديمية.xlsx");
  }

  /* -------- نسخ احتياطي / استرجاع -------- */
  function backupData() {
    const blob = new Blob([JSON.stringify({ players, settings }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "نسخة_احتياطية_الأكاديمية.json";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }
  function restoreData(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        if (Array.isArray(data.players)) setPlayers(data.players);
        if (data.settings) setSettings((s) => ({ ...s, ...data.settings, pin: s.pin }));
      } catch {
        alert("تعذّرت قراءة الملف، تأكد أنه ملف نسخة احتياطية صحيح.");
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  }
  async function shareData() {
    const text = `أكاديمية أسباير - فرع المنيهلة\nعدد اللاعبين: ${stats.total}\nالمدفوع: ${stats.paidCount} / غير المدفوع: ${stats.notPaidCount}\nالمستلم: ${stats.receivedCount} / غير المستلم: ${stats.notReceivedCount}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: "بيانات الأكاديمية", text });
      } catch {}
    } else {
      backupData();
    }
  }

  if (!loaded) {
    return (
      <div style={{ background: NAVY, minHeight: "100vh" }} className="flex items-center justify-center">
        <img src={LOGO_SRC} alt="" className="w-24 h-24 rounded-full animate-pulse" />
      </div>
    );
  }

  if (settings.pin && !unlocked) {
    return <LockScreen pin={settings.pin} onUnlock={() => setUnlocked(true)} />;
  }

  return (
    <div dir="rtl" style={{ background: t.bg, color: t.text, minHeight: "100vh" }} className="font-[system-ui]">
      <style>{`
        * { font-family: 'Tajawal', system-ui, sans-serif; }
        input, select, textarea { font-family: 'Tajawal', system-ui, sans-serif; }
        ::placeholder { color: ${t.muted}; }
        @media print {
          body * { visibility: hidden; }
          #print-area, #print-area * { visibility: visible; }
          #print-area { position: absolute; top: 0; right: 0; left: 0; }
        }
      `}</style>

      {/* الهيدر */}
      <div style={{ background: NAVY }} className="px-4 pt-6 pb-5 flex items-center gap-3 sticky top-0 z-30 shadow-md">
        <img src={LOGO_SRC} alt="شعار الأكاديمية" className="w-11 h-11 rounded-full ring-2" style={{ boxShadow: `0 0 0 2px ${LIME}` }} />
        <div className="flex-1">
          <div className="text-white font-black text-[15px] leading-tight">أكاديمية أسباير</div>
          <div className="text-[11px] leading-tight" style={{ color: LIME }}>فرع المنيهلة</div>
        </div>
        <button
          onClick={() => setSettings((s) => ({ ...s, dark: !s.dark }))}
          className="p-2 rounded-full"
          style={{ background: "rgba(255,255,255,0.08)" }}
        >
          {dark ? <SunMedium size={18} color={LIME} /> : <Moon size={18} color="#fff" />}
        </button>
      </div>

      <div className="pb-24">
        {tab === "home" && (
          <HomeTab
            t={t}
            players={filtered}
            total={players.length}
            query={query}
            setQuery={setQuery}
            showFilters={showFilters}
            setShowFilters={setShowFilters}
            teams={CATEGORIES}
            teamFilter={teamFilter}
            setTeamFilter={setTeamFilter}
            sizeFilter={sizeFilter}
            setSizeFilter={setSizeFilter}
            feeFilter={feeFilter}
            setFeeFilter={setFeeFilter}
            paidFilter={paidFilter}
            setPaidFilter={setPaidFilter}
            receivedFilter={receivedFilter}
            setReceivedFilter={setReceivedFilter}
            onOpen={(p) => setDetailPlayer(p)}
          />
        )}

        {tab === "add" && (
          <PlayerForm
            t={t}
            key={editingId || "new"}
            initial={editingId ? players.find((p) => p.id === editingId) : null}
            teams={CATEGORIES}
            onCancel={() => {
              setEditingId(null);
              setTab("home");
            }}
            onSave={savePlayer}
          />
        )}

        {tab === "stats" && <StatsTab t={t} stats={stats} />}

        {tab === "more" && (
          <MoreTab
            t={t}
            settings={settings}
            setSettings={setSettings}
            onExportExcel={exportExcel}
            onExportPDF={() => window.print()}
            onBackup={backupData}
            onRestoreClick={() => fileInputRef.current?.click()}
            onShare={shareData}
          />
        )}
      </div>

      <input ref={fileInputRef} type="file" accept="application/json" onChange={restoreData} className="hidden" />

      {/* منطقة الطباعة (PDF) */}
      <div id="print-area" className="hidden">
        <h2 style={{ textAlign: "center" }}>أكاديمية أسباير - فرع المنيهلة</h2>
        <table style={{ width: "100%", borderCollapse: "collapse", direction: "rtl" }} border="1" cellPadding="6">
          <thead>
            <tr>
              <th>الاسم واللقب</th>
              <th>الفريق</th>
              <th>المقاس</th>
              <th>معلوم الشهر</th>
              <th>مدفوع</th>
              <th>مستلم</th>
              <th>ملاحظة</th>
            </tr>
          </thead>
          <tbody>
            {players.map((p) => (
              <tr key={p.id}>
                <td>{p.name}</td>
                <td>{p.team}</td>
                <td>{p.size}</td>
                <td>{p.fee}</td>
                <td>{p.paid ? "نعم" : "لا"}</td>
                <td>{p.received ? "نعم" : "لا"}</td>
                <td>{p.remark}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {detailPlayer && (
        <PlayerDetail
          t={t}
          player={detailPlayer}
          onClose={() => setDetailPlayer(null)}
          onEdit={() => {
            setEditingId(detailPlayer.id);
            setDetailPlayer(null);
            setTab("add");
          }}
          onDelete={() => deletePlayer(detailPlayer.id)}
        />
      )}

      <BottomNav
        tab={tab}
        setTab={(tb) => {
          if (tb === "add") setEditingId(null);
          setTab(tb);
        }}
        t={t}
      />
    </div>
  );
}

/* ================= شاشة القفل ================= */
function LockScreen({ pin, onUnlock }) {
  const [entry, setEntry] = useState("");
  const [error, setError] = useState(false);

  function press(d) {
    if (entry.length >= 4) return;
    const next = entry + d;
    setEntry(next);
    if (next.length === 4) {
      if (next === pin) {
        setTimeout(onUnlock, 150);
      } else {
        setError(true);
        setTimeout(() => {
          setEntry("");
          setError(false);
        }, 500);
      }
    }
  }

  return (
    <div dir="rtl" style={{ background: NAVY }} className="min-h-screen flex flex-col items-center justify-center gap-6 px-6">
      <img src={LOGO_SRC} alt="" className="w-24 h-24 rounded-full" style={{ boxShadow: `0 0 0 3px ${LIME}` }} />
      <div className="text-white font-bold">أدخل رمز القفل</div>
      <div className={`flex gap-3 ${error ? "animate-pulse" : ""}`}>
        {[0, 1, 2, 3].map((i) => (
          <div
            key={i}
            className="w-4 h-4 rounded-full"
            style={{ background: i < entry.length ? (error ? "#EF4444" : LIME) : "rgba(255,255,255,0.2)" }}
          />
        ))}
      </div>
      <div className="grid grid-cols-3 gap-4">
        {["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "⌫"].map((d, i) =>
          d === "" ? (
            <div key={i} />
          ) : (
            <button
              key={i}
              onClick={() => (d === "⌫" ? setEntry((e) => e.slice(0, -1)) : press(d))}
              className="w-16 h-16 rounded-full text-white text-xl font-bold flex items-center justify-center"
              style={{ background: "rgba(255,255,255,0.08)" }}
            >
              {d}
            </button>
          )
        )}
      </div>
    </div>
  );
}

/* ================= الشريط السفلي ================= */
function BottomNav({ tab, setTab, t }) {
  const items = [
    { key: "home", icon: HomeIcon, label: "الرئيسية" },
    { key: "add", icon: Plus, label: "إضافة" },
    { key: "stats", icon: BarChart3, label: "إحصائيات" },
    { key: "more", icon: Settings2, label: "المزيد" },
  ];
  return (
    <div
      style={{ background: t.card, borderTop: `1px solid ${t.cardBorder}` }}
      className="fixed bottom-0 inset-x-0 flex justify-around items-center py-2 z-30"
    >
      {items.map(({ key, icon: Icon, label }) => {
        const active = tab === key;
        return (
          <button key={key} onClick={() => setTab(key)} className="flex flex-col items-center gap-1 px-3 py-1">
            <div
              className="w-10 h-10 rounded-2xl flex items-center justify-center transition-all"
              style={{ background: active ? LIME : "transparent" }}
            >
              <Icon size={20} color={active ? "#fff" : t.muted} />
            </div>
            <span style={{ color: active ? LIME : t.muted, fontSize: 11, fontWeight: active ? 700 : 500 }}>{label}</span>
          </button>
        );
      })}
    </div>
  );
}

/* ================= الرئيسية ================= */
function HomeTab(props) {
  const {
    t, players, total, query, setQuery, showFilters, setShowFilters,
    teams, teamFilter, setTeamFilter, sizeFilter, setSizeFilter,
    feeFilter, setFeeFilter,
    paidFilter, setPaidFilter, receivedFilter, setReceivedFilter, onOpen,
  } = props;

  const activeFilters =
    (teamFilter !== "الكل" ? 1 : 0) +
    (sizeFilter !== "الكل" ? 1 : 0) +
    (feeFilter !== "الكل" ? 1 : 0) +
    (paidFilter !== "الكل" ? 1 : 0) +
    (receivedFilter !== "الكل" ? 1 : 0);

  return (
    <div className="px-4 pt-4">
      <div className="flex items-center gap-2 mb-3">
        <div className="flex-1 relative">
          <Search size={17} style={{ color: t.muted }} className="absolute right-3 top-1/2 -translate-y-1/2" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث بالاسم..."
            style={{ background: t.input, borderColor: t.inputBorder, color: t.text }}
            className="w-full rounded-xl border py-2.5 pr-9 pl-3 text-sm outline-none"
          />
        </div>
        <button
          onClick={() => setShowFilters((s) => !s)}
          style={{ background: showFilters ? LIME : t.input, borderColor: t.inputBorder }}
          className="relative rounded-xl border p-2.5"
        >
          <FilterIcon size={18} color={showFilters ? "#fff" : t.muted} />
          {activeFilters > 0 && (
            <span
              className="absolute -top-1 -left-1 text-[10px] w-4 h-4 rounded-full text-white flex items-center justify-center"
              style={{ background: NAVY }}
            >
              {activeFilters}
            </span>
          )}
        </button>
      </div>

      {showFilters && (
        <div style={{ background: t.card, borderColor: t.cardBorder }} className="rounded-2xl border p-3 mb-4 space-y-3">
          <FilterRow label="الفريق" value={teamFilter} onChange={setTeamFilter} options={["الكل", ...teams]} t={t} />
          <FilterRow label="المقاس" value={sizeFilter} onChange={setSizeFilter} options={["الكل", ...SIZES]} t={t} />
          <FilterRow label="معلوم الشهر" value={feeFilter} onChange={setFeeFilter} options={["الكل", ...MONTHLY_FEES]} t={t} />
          <SegRow label="الدفع" value={paidFilter} onChange={setPaidFilter} options={["الكل", "مدفوع", "غير مدفوع"]} t={t} />
          <SegRow label="الاستلام" value={receivedFilter} onChange={setReceivedFilter} options={["الكل", "مستلم", "غير مستلم"]} t={t} />
        </div>
      )}

      <div className="flex items-center justify-between mb-2 px-1">
        <span style={{ color: t.muted }} className="text-xs">
          {players.length} من أصل {total} لاعب
        </span>
      </div>

      {players.length === 0 ? (
        <div style={{ color: t.muted }} className="text-center py-16 text-sm">
          لا يوجد لاعبون مطابقون. أضف لاعباً جديداً من زر "إضافة".
        </div>
      ) : (
        <div className="space-y-2">
          {players.map((p) => (
            <PlayerRow key={p.id} p={p} t={t} onClick={() => onOpen(p)} />
          ))}
        </div>
      )}
    </div>
  );
}

function FilterRow({ label, value, onChange, options, t }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span style={{ color: t.muted }} className="text-xs w-16">{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        style={{ background: t.input, borderColor: t.inputBorder, color: t.text }}
        className="flex-1 rounded-lg border py-1.5 px-2 text-sm outline-none"
      >
        {options.map((o) => (
          <option key={o} value={o}>{o}</option>
        ))}
      </select>
    </div>
  );
}
function SegRow({ label, value, onChange, options, t }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span style={{ color: t.muted }} className="text-xs w-16">{label}</span>
      <div className="flex-1 flex rounded-lg overflow-hidden border" style={{ borderColor: t.inputBorder }}>
        {options.map((o) => (
          <button
            key={o}
            onClick={() => onChange(o)}
            style={{ background: value === o ? LIME : t.input, color: value === o ? "#fff" : t.text }}
            className="flex-1 text-xs py-1.5"
          >
            {o}
          </button>
        ))}
      </div>
    </div>
  );
}

function PlayerRow({ p, t, onClick }) {
  const key = getStatusKey(p);
  const cfg = STATUS_CONFIG[key];
  return (
    <button
      onClick={onClick}
      style={{ background: t.card, borderColor: t.cardBorder }}
      className="w-full flex items-center gap-3 rounded-2xl border p-3 text-right"
    >
      <div
        className="w-11 h-11 rounded-full flex items-center justify-center font-black text-white shrink-0"
        style={{ background: NAVY, boxShadow: `0 0 0 2px ${cfg.dot}` }}
      >
        {p.name?.trim()?.[0] || "?"}
      </div>
      <div className="flex-1 min-w-0">
        <div className="font-bold text-sm truncate">{p.name}</div>
        <div style={{ color: t.muted }} className="text-xs truncate">
          {p.team || "بدون فريق"} · {p.size}{p.fee ? ` · ${p.fee}` : ""}
        </div>
      </div>
      <span
        style={{ background: cfg.soft, color: cfg.text }}
        className="text-[10px] font-bold px-2 py-1 rounded-full whitespace-nowrap"
      >
        {cfg.label}
      </span>
    </button>
  );
}

/* ================= تفاصيل اللاعب ================= */
function PlayerDetail({ t, player, onClose, onEdit, onDelete }) {
  const key = getStatusKey(player);
  const cfg = STATUS_CONFIG[key];
  return (
    <div className="fixed inset-0 z-40 flex items-end" style={{ background: "rgba(0,0,0,0.5)" }} onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        style={{ background: t.card }}
        className="w-full rounded-t-3xl p-5 space-y-4 max-h-[85vh] overflow-y-auto"
      >
        <div className="w-10 h-1.5 rounded-full mx-auto" style={{ background: t.cardBorder }} />
        <div className="flex items-center gap-3">
          <div
            className="w-14 h-14 rounded-full flex items-center justify-center font-black text-white text-xl shrink-0"
            style={{ background: NAVY, boxShadow: `0 0 0 3px ${cfg.dot}` }}
          >
            {player.name?.trim()?.[0] || "?"}
          </div>
          <div className="flex-1">
            <div className="font-black text-lg">{player.name}</div>
            <div style={{ color: t.muted }} className="text-sm">{player.team || "بدون فريق"}</div>
          </div>
          <button onClick={onClose} className="p-2"><X size={20} color={t.muted} /></button>
        </div>

        <span style={{ background: cfg.soft, color: cfg.text }} className="inline-block text-xs font-bold px-3 py-1.5 rounded-full">
          {cfg.label}
        </span>

        <div className="grid grid-cols-2 gap-2">
          <DetailChip t={t} icon={Shirt} label="المقاس" value={player.size} />
          <DetailChip t={t} icon={Wallet} label="معلوم الشهر" value={player.fee || "—"} />
          <DetailChip t={t} icon={Wallet} label="الدفع" value={player.paid ? "مدفوع" : "غير مدفوع"} />
          <DetailChip t={t} icon={PackageCheck} label="الاستلام" value={player.received ? "مستلم" : "غير مستلم"} />
          <DetailChip t={t} icon={Users} label="الفريق" value={player.team || "—"} />
        </div>

        {player.remark && (
          <div style={{ background: t.input, borderColor: t.inputBorder }} className="rounded-xl border p-3 text-sm">
            <div style={{ color: t.muted }} className="text-xs mb-1">ملاحظة</div>
            {player.remark}
          </div>
        )}

        <div className="flex gap-2 pt-2">
          <button onClick={onEdit} style={{ background: LIME }} className="flex-1 rounded-xl py-3 text-white font-bold flex items-center justify-center gap-2">
            <Pencil size={16} /> تعديل
          </button>
          <button
            onClick={() => {
              if (confirm("هل تريد حذف هذا اللاعب؟")) onDelete();
            }}
            className="rounded-xl py-3 px-4 font-bold flex items-center justify-center gap-2"
            style={{ background: "#FEE2E2", color: "#B91C1C" }}
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
function DetailChip({ t, icon: Icon, label, value }) {
  return (
    <div style={{ background: t.input, borderColor: t.inputBorder }} className="rounded-xl border p-2.5 flex items-center gap-2">
      <Icon size={16} color={LIME} />
      <div className="min-w-0">
        <div style={{ color: t.muted }} className="text-[10px]">{label}</div>
        <div className="text-sm font-bold truncate">{value}</div>
      </div>
    </div>
  );
}

/* ================= نموذج إضافة/تعديل لاعب ================= */
function PlayerForm({ t, initial, teams, onCancel, onSave }) {
  const [name, setName] = useState(initial?.name || "");
  const [team, setTeam] = useState(initial?.team || "");
  const [size, setSize] = useState(initial?.size || SIZES[0]);
  const [fee, setFee] = useState(initial?.fee || MONTHLY_FEES[0]);
  const [paid, setPaid] = useState(initial?.paid || false);
  const [received, setReceived] = useState(initial?.received || false);
  const [remark, setRemark] = useState(initial?.remark || "");
  const [showError, setShowError] = useState(false);

  function submit() {
    if (!name.trim()) {
      setShowError(true);
      return;
    }
    onSave({ name: name.trim(), team, size, fee, paid, received, remark: remark.trim() });
  }

  return (
    <div className="px-4 pt-4 space-y-4">
      <h2 className="font-black text-lg">{initial ? "تعديل بيانات اللاعب" : "إضافة لاعب جديد"}</h2>

      <Field t={t} label="👤 الاسم واللقب">
        <input
          value={name}
          onChange={(e) => {
            setName(e.target.value);
            if (showError) setShowError(false);
          }}
          placeholder="مثال: محمد أحمد"
          style={{ background: t.input, borderColor: showError ? "#EF4444" : t.inputBorder, color: t.text }}
          className="w-full rounded-xl border py-2.5 px-3 text-sm outline-none"
        />
        {showError && <div className="text-xs mt-1" style={{ color: "#EF4444" }}>الرجاء إدخال اسم اللاعب</div>}
      </Field>

      <Field t={t} label="👥 الفئة">
        <div className="grid grid-cols-4 gap-2">
          {teams.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => setTeam(c)}
              style={{ background: team === c ? LIME : t.input, color: team === c ? "#fff" : t.text, borderColor: t.inputBorder }}
              className="rounded-lg border py-2 text-xs font-bold"
            >
              {c}
            </button>
          ))}
        </div>
      </Field>

      <Field t={t} label="👕 مقاس التنورة">
        <div className="grid grid-cols-5 gap-2">
          {SIZES.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setSize(s)}
              style={{ background: size === s ? LIME : t.input, color: size === s ? "#fff" : t.text, borderColor: t.inputBorder }}
              className="rounded-lg border py-2 text-xs font-bold"
            >
              {s}
            </button>
          ))}
        </div>
      </Field>

      <Field t={t} label="💵 معلوم الشهر">
        <div className="grid grid-cols-3 gap-2">
          {MONTHLY_FEES.map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => setFee(f)}
              style={{ background: fee === f ? LIME : t.input, color: fee === f ? "#fff" : t.text, borderColor: t.inputBorder }}
              className="rounded-lg border py-2 text-sm font-bold"
            >
              {f}
            </button>
          ))}
        </div>
      </Field>

      <div className="grid grid-cols-2 gap-3">
        <ToggleField t={t} label="💰 دفع" value={paid} onChange={setPaid} />
        <ToggleField t={t} label="📦 استلم" value={received} onChange={setReceived} />
      </div>

      <Field t={t} label="📝 ملاحظة">
        <textarea
          value={remark}
          onChange={(e) => setRemark(e.target.value)}
          rows={3}
          placeholder="اختياري..."
          style={{ background: t.input, borderColor: t.inputBorder, color: t.text }}
          className="w-full rounded-xl border py-2.5 px-3 text-sm outline-none resize-none"
        />
      </Field>

      <div className="flex gap-2 pt-2">
        <button type="button" onClick={submit} style={{ background: LIME }} className="flex-1 rounded-xl py-3 text-white font-bold flex items-center justify-center gap-2">
          <Check size={18} /> {initial ? "حفظ التعديلات" : "إضافة اللاعب"}
        </button>
        <button type="button" onClick={onCancel} style={{ background: t.input, borderColor: t.inputBorder, color: t.text }} className="rounded-xl border py-3 px-5 font-bold">
          إلغاء
        </button>
      </div>
    </div>
  );
}
function Field({ t, label, children }) {
  return (
    <div>
      <div style={{ color: t.muted }} className="text-xs mb-1.5 font-bold">{label}</div>
      {children}
    </div>
  );
}
function ToggleField({ t, label, value, onChange }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!value)}
      style={{ background: value ? LIME : t.input, borderColor: t.inputBorder, color: value ? "#fff" : t.text }}
      className="rounded-xl border py-3 px-3 font-bold text-sm flex items-center justify-between"
    >
      <span>{label}</span>
      <span
        className="w-9 h-5 rounded-full relative transition-colors"
        style={{ background: value ? "rgba(255,255,255,0.35)" : t.inputBorder }}
      >
        <span
          className="absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all"
          style={{ [value ? "right" : "left"]: 2 }}
        />
      </span>
    </button>
  );
}

/* ================= الإحصائيات ================= */
function StatsTab({ t, stats }) {
  const cards = [
    { label: "إجمالي اللاعبين", value: stats.total, color: NAVY },
    { label: "المدفوع", value: stats.paidCount, color: STATUS_CONFIG.green.dot },
    { label: "غير المدفوع", value: stats.notPaidCount, color: STATUS_CONFIG.blue.dot },
    { label: "المستلم", value: stats.receivedCount, color: STATUS_CONFIG.yellow.dot },
    { label: "غير المستلم", value: stats.notReceivedCount, color: STATUS_CONFIG.red.dot },
  ];
  const maxTeam = Math.max(1, ...Object.values(stats.perTeam));
  const maxSize = Math.max(1, ...Object.values(stats.perSize));
  const maxFee = Math.max(1, ...Object.values(stats.perFee || {}));

  return (
    <div className="px-4 pt-4 space-y-5">
      <div className="grid grid-cols-2 gap-2">
        {cards.map((c) => (
          <div key={c.label} style={{ background: t.card, borderColor: t.cardBorder }} className="rounded-2xl border p-3">
            <div className="text-2xl font-black" style={{ color: c.color }}>{c.value}</div>
            <div style={{ color: t.muted }} className="text-xs mt-1">{c.label}</div>
          </div>
        ))}
      </div>

      <div>
        <h3 className="font-black text-sm mb-2">عدد اللاعبين لكل فريق</h3>
        <div style={{ background: t.card, borderColor: t.cardBorder }} className="rounded-2xl border p-3 space-y-2">
          {Object.keys(stats.perTeam).length === 0 && <div style={{ color: t.muted }} className="text-xs">لا توجد بيانات بعد</div>}
          {Object.entries(stats.perTeam).map(([team, count]) => (
            <div key={team}>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-bold">{team}</span>
                <span style={{ color: t.muted }}>{count}</span>
              </div>
              <div className="h-2 rounded-full" style={{ background: t.inputBorder }}>
                <div className="h-2 rounded-full" style={{ width: `${(count / maxTeam) * 100}%`, background: LIME }} />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h3 className="font-black text-sm mb-2">عدد اللاعبين لكل مقاس</h3>
        <div style={{ background: t.card, borderColor: t.cardBorder }} className="rounded-2xl border p-3 space-y-2">
          {Object.keys(stats.perSize).length === 0 && <div style={{ color: t.muted }} className="text-xs">لا توجد بيانات بعد</div>}
          {SIZES.filter((s) => stats.perSize[s]).map((s) => (
            <div key={s}>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-bold">{s}</span>
                <span style={{ color: t.muted }}>{stats.perSize[s]}</span>
              </div>
              <div className="h-2 rounded-full" style={{ background: t.inputBorder }}>
                <div className="h-2 rounded-full" style={{ width: `${(stats.perSize[s] / maxSize) * 100}%`, background: NAVY }} />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h3 className="font-black text-sm mb-2">عدد اللاعبين لكل معلوم شهري</h3>
        <div style={{ background: t.card, borderColor: t.cardBorder }} className="rounded-2xl border p-3 space-y-2">
          {Object.keys(stats.perFee || {}).length === 0 && <div style={{ color: t.muted }} className="text-xs">لا توجد بيانات بعد</div>}
          {MONTHLY_FEES.filter((f) => stats.perFee?.[f]).map((f) => (
            <div key={f}>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-bold">{f}</span>
                <span style={{ color: t.muted }}>{stats.perFee[f]}</span>
              </div>
              <div className="h-2 rounded-full" style={{ background: t.inputBorder }}>
                <div className="h-2 rounded-full" style={{ width: `${(stats.perFee[f] / maxFee) * 100}%`, background: LIME_DARK }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ================= المزيد (إعدادات) ================= */
function MoreTab({ t, settings, setSettings, onExportExcel, onExportPDF, onBackup, onRestoreClick, onShare }) {
  const [pinInput, setPinInput] = useState("");
  const [showPinSetup, setShowPinSetup] = useState(false);

  function setPin() {
    if (pinInput.length !== 4 || !/^\d{4}$/.test(pinInput)) {
      alert("الرجاء إدخال رمز مكوّن من 4 أرقام");
      return;
    }
    setSettings((s) => ({ ...s, pin: pinInput }));
    setPinInput("");
    setShowPinSetup(false);
  }
  function removePin() {
    setSettings((s) => ({ ...s, pin: null }));
  }

  return (
    <div className="px-4 pt-4 space-y-5">
      <Section t={t} title="📤 التصدير">
        <MenuButton t={t} icon={FileSpreadsheet} label="تصدير Excel" onClick={onExportExcel} />
        <MenuButton t={t} icon={FileText} label="تصدير PDF (عبر الطباعة)" onClick={onExportPDF} />
        <MenuButton t={t} icon={Share2} label="مشاركة ملخص البيانات" onClick={onShare} />
      </Section>

      <Section t={t} title="💾 النسخ الاحتياطي">
        <MenuButton t={t} icon={Download} label="تنزيل نسخة احتياطية" onClick={onBackup} />
        <MenuButton t={t} icon={Upload} label="استرجاع من نسخة احتياطية" onClick={onRestoreClick} />
      </Section>

      <Section t={t} title="🔒 الأمان">
        {settings.pin ? (
          <MenuButton t={t} icon={KeyRound} label="إزالة رمز القفل" danger onClick={removePin} />
        ) : !showPinSetup ? (
          <MenuButton t={t} icon={Lock} label="تفعيل رمز قفل (4 أرقام)" onClick={() => setShowPinSetup(true)} />
        ) : (
          <div style={{ background: t.card, borderColor: t.cardBorder }} className="rounded-xl border p-3 space-y-2">
            <input
              value={pinInput}
              onChange={(e) => setPinInput(e.target.value.replace(/\D/g, "").slice(0, 4))}
              placeholder="0000"
              inputMode="numeric"
              style={{ background: t.input, borderColor: t.inputBorder, color: t.text }}
              className="w-full text-center tracking-[0.5em] rounded-lg border py-2 text-lg font-bold outline-none"
            />
            <div className="flex gap-2">
              <button onClick={setPin} style={{ background: LIME }} className="flex-1 rounded-lg py-2 text-white text-sm font-bold">تأكيد</button>
              <button onClick={() => setShowPinSetup(false)} style={{ color: t.muted }} className="px-3 text-sm">إلغاء</button>
            </div>
          </div>
        )}
      </Section>

      <div style={{ color: t.muted }} className="text-[11px] text-center pt-2 pb-4 leading-relaxed">
        <ShieldCheck size={14} className="inline-block ml-1" style={{ verticalAlign: "-2px" }} />
        جميع البيانات محفوظة على هذا الجهاز وتعمل دون اتصال بالإنترنت.
      </div>
    </div>
  );
}
function Section({ t, title, children }) {
  return (
    <div>
      <h3 className="font-black text-sm mb-2">{title}</h3>
      <div className="space-y-2">{children}</div>
    </div>
  );
}
function MenuButton({ t, icon: Icon, label, onClick, danger }) {
  return (
    <button
      onClick={onClick}
      style={{ background: t.card, borderColor: danger ? "#FCA5A5" : t.cardBorder, color: danger ? "#B91C1C" : t.text }}
      className="w-full flex items-center gap-3 rounded-xl border p-3 text-sm font-bold"
    >
      <Icon size={18} color={danger ? "#B91C1C" : LIME} />
      <span className="flex-1 text-right">{label}</span>
      <ChevronLeft size={16} style={{ color: t.muted }} />
    </button>
  );
}
