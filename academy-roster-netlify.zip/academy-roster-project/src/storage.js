// طبقة تخزين محلية (localStorage) بديلة عن window.storage الخاصة ببيئة الـ Artifacts.
// تحافظ على نفس الشكل (get/set) حتى يعمل بقية الكود دون تعديل يُذكر.

const storage = {
  async get(key) {
    const value = localStorage.getItem(key);
    if (value === null) return null;
    return { key, value };
  },
  async set(key, value) {
    localStorage.setItem(key, value);
    return { key, value };
  },
  async delete(key) {
    localStorage.removeItem(key);
    return { key, deleted: true };
  },
};

export default storage;
